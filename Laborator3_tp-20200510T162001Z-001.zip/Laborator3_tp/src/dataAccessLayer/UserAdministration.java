package dataAccessLayer;

import java.sql.*;
import com.mysql.jdbc.PreparedStatement;

public class UserAdministration {
	Connection con=null;
public UserAdministration() throws ClassNotFoundException, SQLException{
	Class.forName("com.mysql.jdbc.Driver");
	con = DriverManager.getConnection("jdbc:mysql://localhost:3306/manage","root","Anonimus1.");
}
	public void insertClient(String username ,String password) throws SQLException{
		String s1 = "INSERT INTO useri (username,password) VALUES (?,?)";
		PreparedStatement st = (PreparedStatement) con.prepareStatement(s1);
		st.setString(1, username);
		st.setString(2, password);
		st.executeUpdate();
		st.close();
	}
	
}

