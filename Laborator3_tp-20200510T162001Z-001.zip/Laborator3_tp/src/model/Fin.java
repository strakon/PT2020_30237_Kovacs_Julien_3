package model;
import java.sql.*;
import java.awt.EventQueue;
import presentation.Psw;

public class Fin {
	
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Psw window = new Psw();
				window.framePsw.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
