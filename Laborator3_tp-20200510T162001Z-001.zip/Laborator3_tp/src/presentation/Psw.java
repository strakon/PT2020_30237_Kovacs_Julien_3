package presentation;


import java.sql.*;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import com.mysql.jdbc.PreparedStatement;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class Psw {
	

	public JFrame framePsw;
	private JPasswordField passwordField;
	private JTextField textField;
	private JButton btnNewButton_1;
	public Connection con=null;
	public Psw() throws ClassNotFoundException, SQLException {
		initialize();
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/manage","root","Anonimus1.");
	}
	private void initialize() {
		framePsw = new JFrame();
		framePsw.setTitle("LOGIN");
		framePsw.setBounds(100, 100, 292, 117);
		framePsw.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		framePsw.getContentPane().setLayout(null);
		passwordField = new JPasswordField();
		passwordField.setBounds(75, 43, 89, 20);
		framePsw.getContentPane().add(passwordField);
		
		textField = new JTextField();
		textField.setBounds(75, 12, 89, 20);
		framePsw.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				PreparedStatement st;
				try {String username=textField.getText();
				@SuppressWarnings("deprecation")
				String password=passwordField.getText();
					st = (PreparedStatement) con.prepareStatement("select password from useri where username='"+username+"'");
					ResultSet rsD=st.executeQuery("select password from useri where username='"+username+"'");
					while(rsD.next()){
						System.out.println(rsD.getString("password"));
						if(password.equals(rsD.getString("password"))){
							JOptionPane.showMessageDialog(framePsw, "Sucessfully logged in");
							
							textField.setText("");
							passwordField.setText("");
						try {
							Man man = new Man();
							man.setVisible(true);
							framePsw.setVisible(false);
						} catch (ClassNotFoundException | SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							
						}}
						else{
							textField.setText("");
							passwordField.setText("");
							JOptionPane.showMessageDialog(framePsw, "Invalidd username or password");}
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
				
			}
		});
		btnNewButton.setBounds(171, 11, 92, 23);
		framePsw.getContentPane().add(btnNewButton);
		
		JLabel lblUser = new JLabel("Username:");
		lblUser.setBounds(10, 11, 68, 23);
		framePsw.getContentPane().add(lblUser);
		
		JLabel lblNewLabel = new JLabel("Password:");
		lblNewLabel.setBounds(10, 42, 69, 23);
		framePsw.getContentPane().add(lblNewLabel);
		
		btnNewButton_1 = new JButton("Sign up");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Pop popUP=new Pop();
				popUP.setVisible(true);
				framePsw.setVisible(false);
				
			}
		});
		btnNewButton_1.setBounds(174, 42, 89, 23);
		framePsw.getContentPane().add(btnNewButton_1);
		
		
	}

	public void setVisible(boolean b) {
		framePsw.setVisible(true);
		
	}
}
