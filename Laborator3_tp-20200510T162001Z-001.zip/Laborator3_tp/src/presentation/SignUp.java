package presentation;
import javax.swing.JFrame;
import javax.swing.JTextField;

import dataAccessLayer.UserAdministration;

import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class SignUp {

	private JFrame frame;
	private JTextField textField_2;
	private JTextField textField_3;
	public SignUp() {
		initialize();
	}
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 186, 140);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField_2 = new JTextField();
		textField_2.setBounds(69, 11, 86, 20);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(69, 42, 86, 20);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		JButton btnSignUp = new JButton("Sign up");
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					Psw man = new Psw();
					man.setVisible(true);
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				try {
					String Username=textField_2.getText();
					String Password=textField_3.getText();
					UserAdministration usr=new UserAdministration();
					usr.insertClient(Username, Password);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				frame.setVisible(false);
				
			}
			
		});
		btnSignUp.setBounds(66, 73, 89, 23);
		frame.getContentPane().add(btnSignUp);
		
		JLabel lblAdresa = new JLabel("Username");
		lblAdresa.setBounds(10, 11, 106, 20);
		frame.getContentPane().add(lblAdresa);
		
		JLabel lblTelefon = new JLabel("Password");
		lblTelefon.setBounds(10, 42, 106, 20);
		frame.getContentPane().add(lblTelefon);
	}

	public void setVisible(boolean b) {
		frame.setVisible(true);
		
	}

}
